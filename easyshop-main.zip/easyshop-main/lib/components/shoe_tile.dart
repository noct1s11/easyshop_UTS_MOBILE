import 'package:flutter/material.dart';

class ShoeTile extends StatelessWidget {
  const ShoeTile({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}